from django.apps import AppConfig


class Services1Config(AppConfig):
    name = 'services1'
